﻿using System;
using Exercise01;

namespace Exercise02
{
    class Program
    {
        static void Main(string[] args)
        {             
            Console.WriteLine("Enter a Number to convert to words");
            string numberInput = Console.ReadLine();
            var myNumberType = (ulong)UInt64.Parse(numberInput);
            var result = Exercise1.Towards(myNumberType);
            Console.WriteLine("The number in words is \n{0}", result);
            Console.ReadKey();
        }
    }
}
